# Modelling Project Final Submission

This folder should contain the extra documents for the deliverables (D3) - (D5)

Student Edit: 
The run.py is the most updated version of our models, and the 1stRun through 4thRun python files shows our progress through the implementation. 
We have included the jape file (japeproofs2.j and japeproofs2.txt). There are pictures of the sovled jape sequents with the English explanation of the premises on the documentation.pdf
The docu.pdf is included as a pdf and there is a link to the google doc here: https://drive.google.com/file/d/1hbKXnk5KbkgTxHahDiHalutJEQuS9t-P/view?usp=sharing

Thank you! Sincerely Group 67

## Due Date

December 9th,  2020

## Expected Items

* *this repository*: We will download the most recent version of your project (including this folder) on the due date.
* `proofs.jp`: Jape file containing sequents, as well as their proofs.
* `modelling_report.docx` or `modelling_report.pptx` or (`report.txt` and `report.pdf`): Include either the Word/PowerPoint document for your documentation, or a link to the OverLeaf project inside of `report.txt` if that is what you chose to use for (D5). If you are using OverLeaf, include a compiled version here as `report.pdf`.
